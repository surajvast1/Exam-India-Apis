const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const dotenv = require("dotenv");
dotenv.config();
const port = process.env.PORT;
let cors = require("cors");

var corsOptions = {
  origin: "*",
  methods: ["GET", "POST", "PUT", "DELETE"],
  optionsSuccessStatus: 200, // For legacy browser support
};
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(cors(corsOptions));
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});

const { swaggerUi, swaggerSpecs } = require("./config/swagger.config");

app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpecs, { explorer: true })
);

const userRoute = require("./routes/user");
const mailRoute = require("./routes/mail");
const forgotpasswordRoute = require("./routes/forgotpassword");
const mobileRoute = require("./routes/mobile");
const apirequest = require("./routes/apirequest");
const uploadimage = require("./routes/uploadimage");
const news_api = require("./routes/news_api");
const examuser = require("./routes/exam_user2");
const exam_admin = require("./routes/exam_admin2");
const user_exam = require("./routes/user_exam");
app.get("/", (req, res) => {
  res.send("Exam india apis");
});

app.use("/user", userRoute);
app.use("/mail", mailRoute);
app.use("/forgotpassword", forgotpasswordRoute);
app.use("/mobile", mobileRoute);
app.use("/apirequest", apirequest);
app.use("/uploadimage", uploadimage);
app.use("/newsfetch", news_api);
app.use("/exam_user", examuser);
app.use("/exam_admin", exam_admin);
app.use("/user_exam",user_exam);

app.listen(port, () => {
  console.log(`App running on port ${port}.`);
});
