const AWS = require("aws-sdk");
require("dotenv").config();
const express = require("express");
const router = express.Router();
const Client = require("pg").Pool;

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
  // ssl: true,
});

client.connect().then(() => {
  console.log("Connected to the database");
});
// Function to generate random number
function generateRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

// Function to send OTP using AWS-SNS
async function sendOTP(mobileNo) {
  const OTP = generateRandomNumber(1000, 9999);

  const params = {
    Message: `Welcome! Your mobile verification code is: ${OTP}. Mobile Number is: ${mobileNo}`,
    PhoneNumber: mobileNo,
  };

  try {
    const sns = new AWS.SNS();
    const message = await sns.publish(params).promise();
    console.log("OTP SEND SUCCESS");
    return OTP;
  } catch (err) {
    console.log("Error:", err);
    throw err;
  }
}

// Configure AWS SDK with credentials and region
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

// API endpoint for sending OTP
router.post("/send-otp", async (req, res) => {
  const mobileNo = req.body.mobileNo;

  if (!mobileNo) {
    return res.status(404).json({ error: "Enter mobile number" });
  }
  try {
    // Check if the mobile number exists in the database
    const checkQuery = `SELECT * FROM users WHERE mobile = $1`;
    const checkParams = [mobileNo];
    const checkResult = await client.query(checkQuery, checkParams);

    if (checkResult.rowCount === 0) {
      res.status(404).json({ error: "Mobile number not found" });
      return;
    }

    try {
      const otp = generateRandomNumber(1000, 9999);

      // Send OTP using AWS-SNS
      const snsParams = {
        Message: `Welcome! Your mobile verification code is: ${otp}. Mobile Number is: ${mobileNo}`,
        PhoneNumber: mobileNo,
      };

      let snsResponse;
      const sns = new AWS.SNS();

      try {
        snsResponse = await sns.publish(snsParams).promise();
      } catch (err) {
        console.log(err);
      }

      if (snsResponse.MessageId) {
        console.log("OTP sent via AWS SNS");

        // Update the OTP in the database
        const updateQuery = `UPDATE users SET mobileotp = $1 WHERE mobile = $2`;
        const updateParams = [otp, mobileNo];
        const updateResult = await client.query(updateQuery, updateParams);

        if (updateResult.rowCount > 0) {
          console.log("OTP updated in the database");
          res.status(200).json({ message: "OTP sent successfully" });
        } else {
          console.error("Error updating OTP in the database");
          res
            .status(500)
            .json({ error: "Failed to update OTP in the database" });
        }
      } else {
        console.error("Error sending OTP via AWS SNS");
        res.status(500).json({ error: "Failed to send OTP" });
      }
    } catch (error) {
      console.error("Error sending OTP or updating in the database: ", error);
      res.status(500).json({ error: "Failed to send OTP" });
    }
  } catch (error) {
    console.error("Error checking mobile number in the database: ", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/verifyotp", async (req, res) => {
  try {
    const { mobileNo, otp_entered } = req.body;

    const data = await client.query("SELECT * FROM users WHERE mobile = $1;", [
      mobileNo,
    ]);
    const arr = data.rows;

    if (arr.length === 0) {
      return res.status(404).json({
        error: "mobile number not found.",
      });
    } else {
      client.query(
        "SELECT mobileotp FROM users WHERE mobile = $1;",
        [mobileNo],
        (error, results) => {
          if (error) {
            return res.status(400).json({
              error: "Error fetching data",
            });
          } else {
            if (results.rows[0].mobileotp == otp_entered) {
              client.query(
                "UPDATE users SET mobileotpverify = true WHERE mobile = $1",
                [mobileNo],
                (error, results) => {
                  if (error) {
                    return res.status(400).json({
                      error: "Error updating data",
                    });
                  }
                  res
                    .status(200)
                    .json({ message: "OTP verified successfully" });
                }
              );
            } else {
              res.status(400).json({ error: "Invalid OTP" });
            }
          }
        }
      );
    }
  } catch (err) {
    res.status(500).json({
      error: "Database error while verifying OTP",
    });
  }
});

module.exports = router;
