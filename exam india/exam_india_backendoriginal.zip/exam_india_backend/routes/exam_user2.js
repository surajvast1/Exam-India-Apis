const express = require("express");
const router = express.Router();
const dotenv = require("dotenv");
dotenv.config();
const Client = require("pg").Pool;

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

client.connect().then(() => {
  console.log("Connected to the exam database1");
});

function executeQuery(sqlQuery, sqlParams) {
  return new Promise((resolve, reject) => {
    client.query(sqlQuery, sqlParams, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}

// ----------------------Category---------------------------------------------------------

router.get("/allcategory", async (req, res) => {
  try {
    let checkQuery = `SELECT * FROM category`;
    executeQuery(checkQuery)
      .then((result) => {
        res.json(result.rows);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});


// ----------------------Exam---------------------------------------------

router.get("/allexam", async (req, res) => {
  try {
    const category_id = req.body.category_id;

    if (!category_id ) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let query = `SELECT * FROM Exam WHERE Category_id = $1 `;
    executeQuery(query, [category_id])
      .then((result) => {
        res.json(result.rows);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
// ----------------------Questions--------------------------------------

router.get("/allquestion", async (req, res) => {
  try {
    const exam_id = req.body.exam_id;

    if ( !exam_id ) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let examQuery = `SELECT * FROM Exam WHERE Exam_id = $1`;

    Promise.all([
      executeQuery(examQuery, [exam_id]),
    ])

      .then(([ examResult]) => {
        if (examResult.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }

        let readQuery = `SELECT * FROM Questions WHERE Exam_id = $1;`;
        executeQuery(readQuery, [ exam_id])
          .then((result) => {
            res.json({
                data: result.rows.map(row => ({
                  questions_id: row.question,
                  image_url: row.image_url,
                  option_a: row.option_a,
                  image_aurl:row.image_aurl,
                  option_b:row.option_b,
                  image_burl:row.image_burl,
                  option_c:row.option_c,
                  image_aurl:row.image_curl,
                  option_d:row.option_d,
                  image_durl:row.image_durl,
                  correct_answer:row.correct_answer,
                  question_description:row.question_description,
                }))
              });
              
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

module.exports = router;
