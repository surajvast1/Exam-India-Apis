const express = require("express");
const { parse } = require("rss-to-json");
const moment = require("moment");
const app = express();

const { Pool } = require("pg");
const dotenv = require("dotenv");
dotenv.config();

const pool = new Pool({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

pool.connect((err) => {
  if (err) {
    console.error("Error connecting to the postgress database:", err);
    return;
  }
  console.log("Connected to the postgress database");
});

app.get("/", async (req, res) => {
  res.send("hiii entered ");
});

app.get("/feeds", async (req, res) => {
  try {
    let { date, ...queries } = req.query;

    if (!date) {
      const currentDate = new Date();
      const day = currentDate.getDate();
      const month = currentDate.getMonth() + 1;
      const year = currentDate.getFullYear();
      const formattedDate = `${day}/${month}/${year}`;
      date = formattedDate;
      console.log(date);
    }

    const rssFeedUrls = [
      "https://timesofindia.indiatimes.com/rssfeedstopstories.cms",
      "https://timesofindia.indiatimes.com/rssfeedmostrecent.cms",
      "https://www.jagranjosh.com/rss/josh/article.xml",
      "https://www.thehindu.com/news/cities/feeder/default.rss",
      "https://www.thehindubusinessline.com/news/feeder/default.rss",
    ];

    const allItems = [];
    let counter = 1;

    for (const url of rssFeedUrls) {
      try {
        const rss = await parse(url);
        const modifiedItems = rss.items
          .map((item) => {
            const published = moment(item.published).toDate();
            const formattedPublished = moment(published).format(
              "DD/MM/YYYY, h:mm:ss A"
            );

            const differentiationFactor = `${formattedPublished}-${counter}`;
            const modifiedDifferentiationFactor = differentiationFactor.replace(
              /[\s,]/g,
              ""
            );
            counter++;
            return {
              id: modifiedDifferentiationFactor,
              title: item.title,
              description: item.description,
              link: item.link,
              author: item.author,
              published: item.published,
              created: item.created,
              enclosures: item.enclosures,
              publishedDate: formattedPublished,
            };
          })
          .filter(Boolean);

        allItems.push(...modifiedItems);
      } catch (error) {
        console.error(`Error parsing RSS feed: ${url}`, error);
      }
    }

    // return res.json(allItems);
    let filteredItems = allItems;

    if (date) {
      const queryDate = moment(date, "DD/MM/YYYY").toDate();
      filteredItems = allItems.filter((item) => {
        const itemDate = moment(
          item.publishedDate,
          "DD/MM/YYYY, h:mm:ss A"
        ).toDate();
        return (
          itemDate.getFullYear() === queryDate.getFullYear() &&
          itemDate.getMonth() === queryDate.getMonth() &&
          itemDate.getDate() === queryDate.getDate()
        );
      });
    }

    const sortedItems = filteredItems.sort((a, b) => {
      const dateA = new Date(a.publishedDate);
      const dateB = new Date(b.publishedDate);
      return dateB - dateA;
    });

    console.log(
      "News fetching operation successfull of length " + sortedItems.length
    );
    res.json(sortedItems);
  } catch (error) {
    console.error("Error retrieving RSS feeds:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.post("/addtobookmark", async (req, res) => {
  const { email } = req.body;
  const { news } = req.body;

  if (!news || !email) {
    res.status(400).json({ error: "Missing required parameters" });
    return;
  }

  try {
    const client = await pool.connect();
    // Check if the email exists in the database
    const checkEmailQuery = "SELECT * FROM users WHERE email = $1";
    const checkEmailValues = [email];
    const emailResult = await client.query(checkEmailQuery, checkEmailValues);

    if (emailResult.rows.length === 0) {
      res.status(404).json({ error: "Email not found" });
      client.release();
      return;
    }

    const existingBookmarks = emailResult.rows[0].bookmarks || "";

    if (existingBookmarks.length > 0) {
      const existingBookmarkIds = existingBookmarks.split("\n");
      if (existingBookmarkIds.includes(JSON.stringify(news))) {
        res.status(400).json({ error: "Bookmark already exists" });
        return;
      }
      existingBookmarkIds.push(JSON.stringify(news));
      updatedBookmarks = existingBookmarkIds.join("\n") + "\n";
    } else {
      updatedBookmarks = JSON.stringify(news) + "\n";
    }

    const updateQuery = "UPDATE users SET bookmarks = $1 WHERE email = $2";
    const values = [updatedBookmarks, email];
    await client.query(updateQuery, values);

    client.release();

    res
      .status(200)
      .json({ success: true, message: "Bookmark added successfully" });
  } catch (error) {
    console.error("Error adding bookmark:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get("/bookmarks", async (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.status(400).json({ error: "Enter email" });
    return;
  }
  const client = await pool.connect();

  try {
    const checkEmailQuery = "SELECT * FROM users WHERE email = $1";
    const checkEmailValues = [email];
    const emailResult = await client.query(checkEmailQuery, checkEmailValues);

    if (emailResult.rows.length === 0) {
      res.status(404).json({ error: "Email not found" });
      client.release();
      return;
    }

    const existingBookmarks = emailResult.rows[0].bookmarks || "";

    if (existingBookmarks.length > 0) {
      const existingBookmarkIds = existingBookmarks.split("\n").filter(Boolean);
      const bookmarkArray = existingBookmarkIds.map(JSON.parse);
      // console.log(bookmarkArray);
      return res.status(200).json(bookmarkArray);
    } else {
      return res
        .status(200)
        .json({ message: "No bookmarks exist in the database" });
    }

    console.log();
    client.release();
  } catch (err) {
    console.log(err);
  }
});

module.exports = app;
