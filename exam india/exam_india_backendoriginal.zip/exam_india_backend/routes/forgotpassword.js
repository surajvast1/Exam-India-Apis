const express = require("express");
const router = express.Router();
const nodemailer = require("nodemailer");
const { Client } = require("pg");
const bcrypt = require("bcrypt");
require("dotenv").config();

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});
client.connect();
function generateOTP(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

router.post("/", async (req, res) => {
  try {
    const { email } = req.body;
    const data1 = await client.query("SELECT * FROM users WHERE email = $1;", [
      email,
    ]);
    const arr = data1.rows;

    if (arr.length === 0) {
      return res.status(404).json({
        error: "Email not found.",
      });
    } else {
      const otp = generateOTP(1000, 9999); // Generate your OTP here

      // Send the OTP via email
      const emailResult = await sendEmail(email, otp);

      // Store the OTP in the database
      if (emailResult) {
        await storeOTPInDatabase(email, otp);
        res.json({
          success: "OTP sent and stored successfully.",
        });
      } else {
        res.status(500).json({
          error: "Failed to send OTP.",
        });
      }
    }
  } catch (error) {
    res.status(500).json({
      error: "Internal server error while sending OTP",
    });
  }
});

// Function to send OTP via email
async function sendEmail(email, otp) {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "venki21122@gmail.com",
        pass: "mtibzgslckzlnhnz",
      },
    });

    const mailOptions = {
      from: "venki21122@gmail.com",
      to: email,
      subject: "OTP Verification",
      text: `Your forgotpassword OTP is: ${otp}`,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Message sent: " + info.response);
    return true;
  } catch (error) {
    console.error("Error sending email: " + error);
    return false;
  }
}

// Function to store OTP in the database
async function storeOTPInDatabase(email, otp) {
  try {
    await client.query(
      "UPDATE users SET forgotpassotp = $1 WHERE email = $2;",
      [otp, email]
    );
  } catch (error) {
    console.error("Error storing OTP in database: " + error);
    throw error;
  }
}

router.post("/verifyotp", async (req, res) => {
  try {
    const { email, otp_entered, password } = req.body;

    const userData = await client.query(
      "SELECT * FROM users WHERE email = $1;",
      [email]
    );
    const user = userData.rows[0];

    if (!user) {
      return res.status(404).json({
        error: "Email not found.",
      });
    }

    const storedOTP = user.forgotpassotp;

    if (storedOTP == otp_entered) {
      const salt = await bcrypt.genSalt(10);
      const hashPassword = await bcrypt.hash(password, salt);

      await client.query("UPDATE users SET password = $1 WHERE email = $2;", [
        hashPassword,
        email,
      ]);

      res
        .status(200)
        .json({ message: "OTP verified and password updated successfully" });
    } else {
      res.status(400).json({ error: "Invalid OTP" });
    }
  } catch (err) {
    res.status(500).json({
      error: "Database error while verifying OTP and updating password",
    });
  }
});

module.exports = router;
