const mysql = require("mysql");
const express = require("express");
const router = express.Router();

const dotenv = require("dotenv");
dotenv.config();

const pool = mysql.createPool({
  host: process.env.HOST,
  database: process.env.DATABASE,
  user: process.env.USER,
  password: process.env.PASSWORD,
});

pool.getConnection((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    return;
  }
  console.log("Connected to the Mysql database");
});

function executeQuery(sqlQuery, sqlParams) {
  return new Promise((resolve, reject) => {
    pool.query(sqlQuery, sqlParams, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}

//this will help to set a particular id and set its id to active//

router.get("/reviewquestions", async (req, res) => {
  try {
    const query = req.query;
    let sqlQuery = "SELECT * FROM tb_soal WHERE question_status = 'On review'";
    let sqlParams = [];

    for (const key in query) {
      if (query.hasOwnProperty(key)) {
        sqlQuery += ` AND ${key} = ?`;
        sqlParams.push(query[key]);
      }
    }

    executeQuery(sqlQuery, sqlParams)
      .then((activeData) => {
        if (activeData.length === 0) {
          return res.status(404).json({
            message: "No questions for review",
          });
        }
        res.json(activeData);
      })
      .catch(() => {
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

//this will  help to search by id//

router.get("/marked_for_Submit", (req, res) => {
  res.send("Cannot get /marked_for_submit");
});

router.post("/marked_for_Submit", async (req, res) => {
  const { id } = req.body;
  if (!id) {
    return res.status(400).json({
      error: "Provide id for verification ",
    });
  }
  try {
    let sqlQuery = "UPDATE tb_soal SET question_status = ? WHERE id_soal = ?";
    let sqlParams = ["Submitted", id];

    executeQuery(sqlQuery, sqlParams)
      .then(() => {
        res.json({
          message: "Submitted sucessfully",
        });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

router.get("/set_for_review", (req, res) => {
  res.send("Cannot get /set_for_review");
});

router.post("/set_for_review", async (req, res) => {
  try {
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({
        error: "Provide id for setting for review ",
      });
    }

    let sqlQuery = "UPDATE tb_soal SET question_status = ? WHERE id_soal = ?";
    let sqlParams = ["On review", id];

    executeQuery(sqlQuery, sqlParams)
      .then(() => {
        res.json({
          message: "Added for reviewed",
        });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = req.params.id;
    console.log(id);

    if (isNaN(id)) {
      return res.status(400).json({
        error: "Invalid id. Please provide a valid integer to search as id .",
      });
    }

    const query = req.query;
    let sqlQuery = `SELECT * FROM tb_soal WHERE id_soal = ?`;
    let sqlParams = [id];

    for (const key in query) {
      if (query.hasOwnProperty(key)) {
        sqlQuery += ` AND ${key} = ?`;
        sqlParams.push(query[key]);
      }
    }

    executeQuery(sqlQuery, sqlParams)
      .then((activeData) => {
        if (activeData.length === 0) {
          return res.status(404).json({
            message: "Data not present",
          });
        }
        res.json(activeData);
      })
      .catch(() => {
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

module.exports = router;
