const bcrypt = require("bcrypt");
const express = require("express");
const AWS = require("aws-sdk");
require("dotenv").config();
const router = express.Router();
const Client = require("pg").Pool;
const sendGridMail = require("@sendgrid/mail");

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

client.connect().then(() => {
  console.log("Connected to the database1");
});
const jwt = require("jsonwebtoken");

router.post("/register", async (req, res) => {
  const { email, fullname, password, mobile } = req.body;

  // Server-side validation
  if (!email || !fullname || !password || !mobile) {
    return res.status(400).json({
      error: "All fields are required.",
    });
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({
      error: "Invalid email address.",
    });
  }

  if (!/^[0-9]{10}$/.test(mobile)) {
    return res.status(400).json({
      error: "Invalid mobile number.",
    });
  }

  try {
    const data = await client.query(`SELECT * FROM users WHERE email = $1;`, [
      email,
    ]);
    const arr = data.rows;
    if (arr.length !== 0) {
      return res.status(400).json({
        error: "Email address is already registered.",
      });
    } else {
      const data1 = await client.query(
        `SELECT * FROM users WHERE mobile = $1;`,
        [mobile]
      );
      const arr1 = data1.rows;
      if (arr1.length !== 0) {
        return res.status(400).json({
          error: "Mobile number is already registered.",
        });
      } else {
        bcrypt.hash(password, 10, (err, hash) => {
          if (err) {
            console.error(err);
            return res.status(400).json({
              error: "Server error",
            });
          }
          const user = {
            email,
            fullname,
            password: hash,
            mobile,
            verified: false,
            mobileotpverify: false,
          };

          // Inserting data into the database
          client.query(
            `INSERT INTO users (email, fullname, password, mobile, verified, mobileotpverify) VALUES ($1, $2, $3, $4, $5, $6);`,
            [
              user.email,
              user.fullname,
              user.password,
              user.mobile,
              user.verified,
              user.mobileotpverify,
            ],
            (err) => {
              if (err) {
                console.error(err);
                return res.status(400).json({
                  error: "Database error",
                });
              } else {
                res.status(200).json({
                  message: "User added to database, not verified",
                });
              }
            }
          );
        });
      }
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: "Database error while registering user!",
    });
  }
});

// login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      error: "Email and password are required!",
    });
  }

  try {
    const data = await client.query(`SELECT * FROM users WHERE email= $1;`, [
      email,
    ]); //Verifying if the user exists in the database
    const user = data.rows;
    if (user.length === 0) {
      res.status(400).json({
        error: "User is not registered, Sign Up first",
      });
    } else {
      bcrypt.compare(password, user[0].password, (err, result) => {
        if (err) {
          res.status(500).json({
            error: "Server error",
          });
        } else if (result === true) {
          const token = jwt.sign(
            {
              email: email,
            },
            "hey this is test"
          );

          res.status(200).json({
            message: "User signed in!",
            body: {
              email: user.email,
              fullname: user.fullname,
              password: user.password,
              mobile: user.mobile,
            },
            token: token,
          });
        } else {
          if (result != true)
            res.status(400).json({
              error: "Enter correct password!",
            });
        }
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).json({
      error: "Database error occurred while signing in!",
    });
  }
});

// profile function

router.get("/profile/:email", async (req, res) => {
  id = req.params.email;
  try {
    const data = await client.query(`select * from users where email = $1;`, [
      id,
    ]);
    const arr = data.rows;
    if (arr.length === 0) {
      return res.status(404).json({
        error: "no orders found.",
      });
    } else {
      return res.status(200).json({ arr });
    }
  } catch (err) {
    res.status(500).json({
      error: "Database error occurred while fetching profile",
    });
  }
});

router.put("/updateuser", async (req, res) => {
  
  const { email, oldPassword, newPassword } = req.body;

  if (!email || !oldPassword || !newPassword) {
    return res.status(400).json({
      error: "Invalid input",
    });
  }

  const data = await client.query(`SELECT * FROM users WHERE email = $1;`, [
    email,
  ]);
  const user = data.rows[0];

  if (!user) {
    return res.status(400).json({
      error: "User is not registered. Sign up first.",
    });
  }

  bcrypt.compare(oldPassword, user.password, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(400).json({
        error: "Server error",
      });
    }

    if (result === false) {
      return res.status(400).json({
        error: "Incorrect existing password",
      });
    }

    bcrypt.hash(newPassword, 10, (err, hash) => {
      if (err) {
        console.error(err);
        return res.status(400).json({
          error: "Server error",
        });
      }
      client.query(
        `UPDATE users SET password = $1 WHERE email = $2;`,
        [hash, email],
        (err) => {
          if (err) {
            console.error(err);
            return res.status(400).json({
              error: "Database error",
            });
          } else {
            res.status(200).json({
              message: "Password updated",
            });
          }
        }
      );
    });
  });
});

module.exports = router;
