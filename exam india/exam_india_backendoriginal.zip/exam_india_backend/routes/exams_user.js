const express = require("express");
const router = express.Router();
const dotenv = require("dotenv");
dotenv.config();
const Client = require("pg").Pool;

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

client.connect().then(() => {
  console.log("Connected to the exam database1");
});

function executeQuery(sqlQuery, sqlParams) {
  return new Promise((resolve, reject) => {
    client.query(sqlQuery, sqlParams, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}

// ----------------------Category-------------------------------------

router.get("/allcategory", async (req, res) => {
  try {
    let checkQuery = `SELECT * FROM category`;
    executeQuery(checkQuery)
      .then((result) => {
        res.json(result.rows);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// ----------------------Course------------------------------------

router.get("/allcourses", async (req, res) => {
  try {
    let query = `SELECT * FROM Course;`;
    executeQuery(query)
      .then((result) => {
        res.json(result.rows);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.get("/coursesByCategory", async (req, res) => {
  try {
    const category_id = req.body.category_id;

    if (!category_id) {
      return res.status(400).json({
        message: "Category ID is required",
      });
    }

    let categoryQuery = `SELECT * FROM Category WHERE Category_id = $1;`;
    executeQuery(categoryQuery, [category_id])
      .then((result) => {
        if (result.rowCount === 0) {
          return res.status(404).json({
            message: "Category not found Create category ",
          });
        }

        let query = `SELECT * FROM Course WHERE Category_id = $1;`;
        executeQuery(query, [category_id])
          .then((result) => {
            if (result.rowCount === 0) {
              return res.status(200).json({
                message: "No courses found for the given category ID",
              });
            }
            res.json(result.rows);
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// ----------------------Exam---------------------------------------------

router.get("/allexam", async (req, res) => {
  try {
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;

    if (!category_id || !course_id) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let query = `SELECT * FROM Exam WHERE Category_id = $1 AND Course_id = $2;`;
    executeQuery(query, [category_id, course_id])
      .then((result) => {
        res.json(result.rows);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
// ----------------------Questions--------------------------------------

router.get("/allquestion", async (req, res) => {
  try {
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;
    const exam_id = req.body.exam_id;
    const exam_code = req.body.exam_code;

    if (!category_id || !course_id || !exam_id || !exam_code) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let categoryQuery = `SELECT * FROM Category WHERE Category_id = $1;`;
    let courseQuery = `SELECT * FROM Course WHERE Course_id = $1;`;
    let examQuery = `SELECT * FROM Exam WHERE Exam_id = $1 AND Exam_code = $2;`;

    Promise.all([
      executeQuery(categoryQuery, [category_id]),
      executeQuery(courseQuery, [course_id]),
      executeQuery(examQuery, [exam_id, exam_code]),
    ])

      .then(([categoryResult, courseResult, examResult]) => {
        if (categoryResult.rowCount === 0) {
          return res.status(404).json({
            message: "Category not found",
          });
        }
        if (courseResult.rowCount === 0) {
          return res.status(404).json({
            message: "Course not found",
          });
        }
        if (examResult.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }

        let readQuery = `SELECT * FROM Questions WHERE Category_id = $1 AND Course_id = $2 
                            AND Exam_id = $3 AND Exam_code = $4;`;
        executeQuery(readQuery, [category_id, course_id, exam_id, exam_code])
          .then((result) => {
            res.json({
              data: result.rows,
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});


module.exports = router;

// router.get("/marked_for_Submit", (req, res) => {
//   res.send("Cannot get /marked_for_submit");
// });

// router.post("/marked_for_Submit", async (req, res) => {
//   const { id } = req.body;
//   if (!id) {
//     return res.status(400).json({
//       error: "Provide id for verification ",
//     });
//   }
//   try {
//     let sqlQuery = "UPDATE tb_soal SET question_status = ? WHERE id_soal = ?";
//     let sqlParams = ["Submitted", id];

//     executeQuery(sqlQuery, sqlParams)
//       .then(() => {
//         res.json({
//           message: "Submitted sucessfully",
//         });
//       })
//       .catch((err) => {
//         console.log(err);
//         return res.status(500).json({
//           message: "Internal server error",
//         });
//       });
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({
//       message: "Internal server error",
//     });
//   }
// });

// router.get("/set_for_review", (req, res) => {
//   res.send("Cannot get /set_for_review");
// });

// router.post("/set_for_review", async (req, res) => {
//   try {
//     const { id } = req.body;
//     if (!id) {
//       return res.status(400).json({
//         error: "Provide id for setting for review ",
//       });
//     }

//     let sqlQuery = "UPDATE tb_soal SET question_status = ? WHERE id_soal = ?";
//     let sqlParams = ["On review", id];

//     executeQuery(sqlQuery, sqlParams)
//       .then(() => {
//         res.json({
//           message: "Added for reviewed",
//         });
//       })
//       .catch((err) => {
//         console.log(err);
//         return res.status(500).json({
//           message: "Internal server error",
//         });
//       });
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({
//       message: "Internal server error",
//     });
//   }
// });

// // router.get("/:id", async (req, res) => {
// //   try {
// //     const id = req.params.id;
// //     console.log(id);

// //     if (isNaN(id)) {
// //       return res.status(400).json({
// //         error: "Invalid id. Please provide a valid integer to search as id .",
// //       });
// //     }

// //     const query = req.query;
// //     let sqlQuery = `SELECT * FROM tb_soal WHERE id_soal = ?`;
// //     let sqlParams = [id];

// //     for (const key in query) {
// //       if (query.hasOwnProperty(key)) {
// //         sqlQuery += ` AND ${key} = ?`;
// //         sqlParams.push(query[key]);
// //       }
// //     }

// //     executeQuery(sqlQuery, sqlParams)
// //       .then((activeData) => {
// //         if (activeData.length === 0) {
// //           return res.status(404).json({
// //             message: "Data not present",
// //           });
// //         }
// //         res.json(activeData);
// //       })
// //       .catch(() => {
// //         return res.status(500).json({
// //           message: "Internal server error",
// //         });
// //       });
// //   } catch (error) {
// //     return res.status(500).json({
// //       message: "Internal server error",
// //     });
// // //   }  
// // // });

// module.exports = router;
