const AWS = require("aws-sdk");
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const Client = require("pg").Pool;
const bodyParser = require("body-parser");
const dotenv = require("dotenv");

dotenv.config();

AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();
const app = express();

const imageFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/jpg"
  ) {
    cb(null, true);
  } else {
    const errorMessage =
      "Invalid file type. Only PNG JPG and  JPEG images are allowed.";
    cb(null, false);
  }
};

const upload = multer({
  dest: "uploads/",
  fileFilter: imageFilter,
});

const db = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

db.connect()
  .then(() => {
    console.log("Connected to the PostgreSQL22 database");
  })
  .catch((error) => {
    console.error(error);
  });

app.post(
  "/upload",
  upload.fields([{ name: "email" }, { name: "image" }]),
  async (req, res) => {
    const email = req.body.email;
    const files = req.files;

    if (!email && (!files || !files.image)) {
      return res.send("Please add both an email id and an image");
    } else if (!files || !files.image) {
      return res.send("Invalid input");
    } else if (!email) {
      return res.send("Please add email");
    }

    const isEmailVerified = await verifyEmail(email);

    if (!isEmailVerified) {
      return res.send("Email not verified");
    }

    const bucketName = "exam-india-image-upload";
    const fileName = req.files.image[0].originalname;
    const filePath = req.files.image[0].path;

    try {
      const url = await uploadImageToS3(bucketName, fileName, filePath);

      fs.unlinkSync(filePath);
      await saveImageURL(email, url);

      res.status(200).json({
        message: "Image uploaded and URL saved to the database successfully.",
      });
    } catch (error) {
      res.status(200).json({ error: error.message });
    }
  }
);

function uploadImageToS3(bucketName, fileName, filePath) {
  const fileContent = fs.readFileSync(filePath);

  const params = {
    Bucket: bucketName,
    Key: fileName,
    Body: fileContent,
  };

  return new Promise((resolve, reject) => {
    s3.upload(params, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data.Location);
      }
    });
  });
}

async function verifyEmail(email) {
  try {
    const result = await db.query("SELECT email FROM users WHERE email = $1", [
      email,
    ]);
    if (result.rows.length > 0 && result.rows[0].email === email) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error verifying email:", error);
    return false;
  }
}

async function saveImageURL(email, url) {
  try {
    await db.query("UPDATE users SET imageurl = $1 WHERE email = $2", [
      url,
      email,
    ]);
    return true;
  } catch (error) {
    console.error("Error saving image URL:", error);
    return false;
  }
}

app.use((req, res, next) => {
  if (req.is("multipart/form-data")) {
    req.headers["content-type"] = "multipart/form-data";
  }
  next();
});

app.get("/", (req, res) => {
  res.send("Upload image page");
});

module.exports = app;
