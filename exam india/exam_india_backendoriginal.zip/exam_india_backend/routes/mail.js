const express = require("express");
const router = express.Router();
const nodemailer = require("nodemailer");
const { Client } = require("pg");
const middleware = require("../middleware/middleware");
require("dotenv").config();

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
  // ssl: true,
});

client.connect();
function generateOTP(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

// Define the route to handle sending OTP via email and storing it in the database
router.post("/sendOtp", async (req, res) => {
  try {
    const { email } = req.body;
    const data1 = await client.query("SELECT * FROM users WHERE email = $1;", [
      email,
    ]);
    const arr = data1.rows;

    if (arr.length === 0) {
      return res.status(404).json({
        error: "Email not found.",
      });
    } else {
      const otp = generateOTP(1000, 9999); // Generate your OTP here

      // Send the OTP via email
      const emailResult = await sendEmail(email, otp);

      // Store the OTP in the database
      if (emailResult) {
        await storeOTPInDatabase(email, otp);
        res.json({
          success: "OTP sent and stored successfully.",
        });
      } else {
        res.status(500).json({
          error: "Failed to send OTP.",
        });
      }
    }
  } catch (error) {
    res.status(500).json({
      error: "Internal server error while sending OTP",
    });
  }
});

// Function to send OTP via email
async function sendEmail(email, otp) {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "venki21122@gmail.com",
        pass: "mtibzgslckzlnhnz",
      },
    });

    const mailOptions = {
      from: "venki21122@gmail.com",
      to: email,
      subject: "OTP Verification",
      text: `Your OTP is: ${otp}`,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Message sent: " + info.response);
    return true;
  } catch (error) {
    console.error("Error sending email: " + error);
    return false;
  }
}

// Function to store OTP in the database
async function storeOTPInDatabase(email, otp) {
  try {
    await client.query("UPDATE users SET otp = $1 WHERE email = $2;", [
      otp,
      email,
    ]);
  } catch (error) {
    console.error("Error storing OTP in database: " + error);
    throw error;
  }
}

router.get("/verifyotp", async (req, res) => {
  try {
    const { email, otp_entered } = req.body;

    // console.log(email,otp_entered);
    if (!email && !otp_entered) {
      return res.status(404).send({ message: "Enter details properly" });
    }
    const data = await client.query("SELECT * FROM users WHERE email = $1;", [
      email,
    ]);
    const arr = data.rows;

    if (arr.length === 0) {
      return res.status(404).json({
        error: "Email not found.",
      });
    } else {
      client.query(
        "SELECT otp FROM users WHERE email = $1;",
        [email],
        (error, results) => {
          if (error) {
            return res.status(400).json({
              error: "Error fetching data",
            });
          } else {
            if (results.rows[0].otp == otp_entered) {
              // console.log(results.rows[0].otp);
              client.query(
                "UPDATE users SET verified = true WHERE email = $1",
                [email],
                (error, results) => {
                  if (error) {
                    return res.status(400).json({
                      error: "Error updating data",
                    });
                  }
                  res
                    .status(200)
                    .json({ message: "OTP verified successfully" });
                }
              );
            } else {
              res.status(400).json({ error: "Invalid OTP" });
            }
          }
        }
      );
    }
  } catch (err) {
    res.status(500).json({
      error: "Database error while verifying OTP",
    });
  }
});

// Export the router
module.exports = router;
