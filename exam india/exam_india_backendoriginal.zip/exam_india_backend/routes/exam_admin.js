const express = require("express");
const router = express.Router();
const dotenv = require("dotenv");
dotenv.config();
const Client = require("pg").Pool;

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

client.connect().then(() => {
  console.log("Connected to the exam database1");
});

function executeQuery(sqlQuery, sqlParams) {
  return new Promise((resolve, reject) => {
    client.query(sqlQuery, sqlParams, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}
// ---------------Category_api----------------------------
router.post("/createcategory", async (req, res) => {
  try {
    const category_name = req.body.category_name;

    if (!category_name) {
      return res.status(400).json({
        message: "Category name is required",
      });
    }

    let checkQuery = `SELECT * FROM category WHERE Category_name = $1;`;
    executeQuery(checkQuery, [category_name])
      .then((result) => {
        if (result.rowCount > 0) {
          return res.status(409).json({
            message: "Category already exists",
          });
        }

        let insertQuery = `INSERT INTO category (Category_id, Category_name)
                               VALUES (CAST(FLOOR(RANDOM() * 1000000) AS INT), $1);`;
        executeQuery(insertQuery, [category_name])
          .then(() => {
            res.json({
              message: "Category registered successfully",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.delete("/deletecategory", async (req, res) => {
  try {
    const category_name = req.body.category_name;

    if (!category_name) {
      return res.status(400).json({
        message: "Category name is required",
      });
    }

    let checkQuery = `SELECT * FROM category WHERE Category_name = $1;`;
    executeQuery(checkQuery, [category_name])
      .then((result) => {
        if (result.rowCount === 0) {
          return res.status(404).json({
            message: "Category not found",
          });
        }

        let deleteQuery = `DELETE FROM category WHERE Category_name = $1;`;
        executeQuery(deleteQuery, [category_name])
          .then(() => {
            res.json({
              message: "Category deleted successfully",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })

      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// ---------------Course_api----------------------------------------

router.post("/createcourse", async (req, res) => {
  try {
    const course_name = req.body.course_name;
    const category_id = req.body.category_id;

    if (!course_name || !category_id) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let checkQuery = `SELECT * FROM course WHERE course_name = $1;`;
    executeQuery(checkQuery, [course_name])
      .then((result) => {
        if (result.rowCount > 0) {
          return res.status(409).json({
            message: "Course already exists",
          });
        }

        let insertQuery = `INSERT INTO Course (Course_id, Course_name, Category_id)
                               VALUES (CAST(FLOOR(RANDOM() * 1000000) AS INT), $1, $2);`;
        executeQuery(insertQuery, [course_name, category_id])
          .then(() => {
            res.json({
              message: "Course registered successfully",
            });
          })
          .catch((err) => {
            if (err.constraint === "course_category_id_fkey") {
              return res.status(400).json({
                message: "Invalid category ID",
              });
            }

            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.delete("/deletecourse", async (req, res) => {
  try {
    const course_id = req.body.course_id;

    let checkQuery = `SELECT * FROM Course WHERE Course_id = $1;`;
    executeQuery(checkQuery, [course_id])
      .then((result) => {
        if (result.rowCount === 0) {
          return res.status(404).json({
            message: "Course not found",
          });
        }

        let deleteQuery = `DELETE FROM Course WHERE Course_id = $1;`;
        executeQuery(deleteQuery, [course_id])
          .then(() => {
            res.json({
              message: "Course deleted successfully",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// ---------------Exam_api-----------------------------------------

router.post("/createexam", async (req, res) => {
  try {
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;
    const exam_name = req.body.exam_name;
    const exam_duration = req.body.exam_duration;
    const negative_marking = req.body.negative_marking;
    const exam_date = req.body.exam_date;
    const exam_time = req.body.exam_time;
    const exam_id = Math.floor(Math.random() * 1000000);

    if (
      !category_id ||
      !course_id ||
      !exam_name ||
      !exam_duration ||
      !negative_marking ||
      !exam_date ||
      !exam_time
    ) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let checkQuery = `SELECT * FROM Exam WHERE Exam_name = $1 AND Category_id = $2 
          AND Course_id = $3;`;
    executeQuery(checkQuery, [exam_name, category_id, course_id])
      .then((result) => {
        if (result.rowCount > 0) {
          return res.status(409).json({
            message: "Exam already exists",
          });
        }

        let insertQuery = `INSERT INTO Exam (Exam_id, Category_id, Course_id, 
                Exam_name, Exam_code, Exam_duration, Negative_marking, Exam_date, 
                 Exam_time)
                               VALUES ($1, $2, $3, $4, CAST(FLOOR(RANDOM() * 1000000) 
                                 AS INT), $5, $6, $7, $8);`;
        executeQuery(insertQuery, [
          exam_id,
          category_id,
          course_id,
          exam_name,
          exam_duration,
          negative_marking,
          exam_date,
          exam_time,
        ])
          .then(() => {
            res.json({
              message: "Exam registered successfully",
            });
          })
          .catch((err) => {
            if (err.constraint === "exam_category_id_fkey") {
              return res.status(400).json({
                message: "Invalid category ID",
              });
            }
            if (err.constraint === "exam_course_id_fkey") {
              return res.status(400).json({
                message: "Invalid course ID",
              });
            }
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.put("/updateexam", async (req, res) => {
  try {
    const exam_id = req.body.exam_id;
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;
    const exam_name = req.body.exam_name;
    const exam_duration = req.body.exam_duration;
    const negative_marking = req.body.negative_marking;
    const exam_date = req.body.exam_date;
    const exam_time = req.body.exam_time;

    console.log("Exam ID:", exam_id);
    console.log("Category ID:", category_id);
    console.log("Course ID:", course_id);
    console.log("Exam Name:", exam_name);
    console.log("Exam Duration:", exam_duration);
    console.log("Negative Marking:", negative_marking);
    console.log("Exam Date:", exam_date);
    console.log("Exam Time:", exam_time);

    if (
      !exam_id ||
      !category_id ||
      !course_id ||
      !exam_name ||
      !exam_duration ||
      !negative_marking ||
      !exam_date ||
      !exam_time
    ) {
      return res.status(400).json({
        message: "Invalida input",
      });
    }

    let checkQuery = `SELECT * FROM Exam WHERE Exam_id = $1 AND Category_id = $2 
         AND Course_id = $3;`;
    executeQuery(checkQuery, [exam_id, category_id, course_id])
      .then((result) => {
        if (result.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }

        let checkCategoryQuery = `SELECT * FROM Category WHERE Category_id = $1;`;
        executeQuery(checkCategoryQuery, [category_id])
          .then((categoryResult) => {
            if (categoryResult.rowCount === 0) {
              return res.status(404).json({
                message: "Invalid category ID",
              });
            }

            let checkCourseQuery = `SELECT * FROM Course WHERE Course_id = $1;`;
            executeQuery(checkCourseQuery, [course_id])
              .then((courseResult) => {
                if (courseResult.rowCount === 0) {
                  return res.status(404).json({
                    message: "Invalid course ID",
                  });
                }

                let updateQuery = `UPDATE Exam SET Exam_name = $1, Exam_duration = 
                     $2, Negative_marking = $3, Exam_date = $4, Exam_time = $5 WHERE 
                      Exam_id = $6 AND Category_id = $7 AND Course_id = $8;`;
                executeQuery(updateQuery, [
                  exam_name,
                  exam_duration,
                  negative_marking,
                  exam_date,
                  exam_time,
                  exam_id,
                  category_id,
                  course_id,
                ])
                  .then(() => {
                    res.json({
                      message: "Exam details updated successfully",
                    });
                  })
                  .catch((err) => {
                    console.log(err);
                    return res.status(500).json({
                      message: "Internal server error",
                    });
                  });
              })
              .catch((err) => {
                console.log(err);
                return res.status(500).json({
                  message: "Internal server error",
                });
              });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.delete("/deleteexam", async (req, res) => {
  try {
    const exam_id = req.body.exam_id;
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;

    if (!exam_id || !category_id || !course_id) {
      return res.status(400).json({
        message: "Exam ID, category ID, and course ID are required",
      });
    }

    let verifyQuery = `SELECT * FROM Exam WHERE Exam_id = $1 AND Category_id = $2 AND Course_id = $3;`;
    executeQuery(verifyQuery, [exam_id, category_id, course_id])
      .then((result) => {
        if (result.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }

        let deleteQuery = `DELETE FROM Exam WHERE Exam_id = $1;`;
        executeQuery(deleteQuery, [exam_id])
          .then(() => {
            res.json({
              message: "Exam deleted successfully",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// ---------------Questions_api----------------------------------

router.post("/addquestiontoexam", async (req, res) => {
  try {
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;
    const exam_id = req.body.exam_id;
    const exam_code = req.body.exam_code;
    const question = req.body.question;
    const image_url = req.body.image_url;
    const option_A = req.body.option_A;
    const image_Aurl = req.body.image_Aurl;
    const image_Burl = req.body.image_Burl;
    const image_Curl = req.body.image_Curl;
    const image_Durl = req.body.image_Durl;
    const option_B = req.body.option_B;
    const option_C = req.body.option_C;
    const option_D = req.body.option_D;
    const correct_answer = req.body.correct_answer;
    const question_description = req.body.question_description;
    const question_id = Math.floor(Math.random() * 1000000);

    if (
      !category_id ||
      !course_id ||
      !exam_id ||
      !exam_code ||
      !question ||
      !option_A ||
      !option_B ||
      !option_C ||
      !option_D ||
      !correct_answer ||
      !question_description
    ) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    let categoryQuery = `SELECT * FROM Category WHERE Category_id = $1;`;
    let courseQuery = `SELECT * FROM Course WHERE Course_id = $1;`;

    Promise.all([
      executeQuery(categoryQuery, [category_id]),
      executeQuery(courseQuery, [course_id]),
    ])
      .then(([categoryResult, courseResult]) => {
        if (categoryResult.rowCount === 0) {
          return res.status(404).json({
            message: "Category not found",
          });
        }
        if (courseResult.rowCount === 0) {
          return res.status(404).json({
            message: "Course not found",
          });
        }

        let examQuery = `SELECT * FROM Exam WHERE Exam_id = $1 AND Exam_code = $2;`;
        executeQuery(examQuery, [exam_id, exam_code])
          .then((examResult) => {
            if (examResult.rowCount === 0) {
              return res.status(404).json({
                message: "Exam not found",
              });
            }

            let questionQuery = `SELECT * FROM Questions WHERE Question = $1 AND Exam_id = $2;`;
            executeQuery(questionQuery, [question, exam_id])
              .then((questionResult) => {
                if (questionResult.rowCount > 0) {
                  return res.status(409).json({
                    message: "Question already exists in the exam",
                  });
                }

                let insertQuery = `INSERT INTO Questions (Questions_id, Category_id, 
                     Course_id, Exam_id, Exam_code, Question, image_url, option_A, 
                      image_Aurl, image_Burl, image_Curl, image_Durl, option_B, option_C, 
                       option_D, Correct_Answer, Question_Description)
                                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,   $11, $12, $13, $14, $15, $16, $17);`;
                executeQuery(insertQuery, [
                  question_id,
                  category_id,
                  course_id,
                  exam_id,
                  exam_code,
                  question,
                  image_url,
                  option_A,
                  image_Aurl,
                  image_Burl,
                  image_Curl,
                  image_Durl,
                  option_B,
                  option_C,
                  option_D,
                  correct_answer,
                  question_description,
                ])
                  .then(() => {
                    res.json({
                      message: "Question added successfully",
                    });
                  })
                  .catch((err) => {
                    console.log(err);
                    return res.status(500).json({
                      message: "Internal server error",
                    });
                  });
              })
              .catch((err) => {
                console.log(err);
                return res.status(500).json({
                  message: "Internal server error",
                });
              });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});
router.delete("/deletequestion", async (req, res) => {
  try {
    const category_id = req.body.category_id;
    const course_id = req.body.course_id;
    const exam_id = req.body.exam_id;
    const exam_code = req.body.exam_code;
    const question_id = req.body.question_id;

    console.log(question_id);

    if (!category_id || !course_id || !exam_id || !exam_code || !question_id) {
      return res.status(400).json({
        message: "Invaalid input",
      });
    }

    let categoryQuery = `SELECT * FROM Category WHERE Category_id = $1;`;
    let courseQuery = `SELECT * FROM Course WHERE Course_id = $1;`;
    let examQuery = `SELECT * FROM Exam WHERE Exam_id = $1 AND Exam_code = $2;`;
    let questionQuery = `SELECT * FROM Questions WHERE Questions_id = $1;`;

    Promise.all([
      executeQuery(categoryQuery, [category_id]),
      executeQuery(courseQuery, [course_id]),
      executeQuery(examQuery, [exam_id, exam_code]),
      executeQuery(questionQuery, [question_id]),
    ])
      .then(([categoryResult, courseResult, examResult, questionResult]) => {
        if (categoryResult.rowCount === 0) {
          return res.status(404).json({
            message: "Category not found",
          });
        }
        if (courseResult.rowCount === 0) {
          return res.status(404).json({
            message: "Course not found",
          });
        }
        if (examResult.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }
        if (questionResult.rowCount === 0) {
          return res.status(404).json({
            message: "Question not found",
          });
        }

        let deleteQuery = `DELETE FROM Questions WHERE Questions_id = $1;`;
        executeQuery(deleteQuery, [question_id])
          .then(() => {
            res.json({
              message: "Question deleted successfully",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

module.exports = router;
