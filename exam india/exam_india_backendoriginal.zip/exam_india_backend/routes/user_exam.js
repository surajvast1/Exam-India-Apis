const express = require("express");
const router = express.Router();
const dotenv = require("dotenv");
dotenv.config();
const Client = require("pg").Pool;

const client = new Client({
  user: process.env.PUSER,
  host: process.env.PHOST,
  database: process.env.PDATABASE,
  password: process.env.PPASSWORD,
  port: process.env.PPORT,
});

client.connect().then(() => {
  console.log("Connected to the exam database3");
});

function executeQuery(sqlQuery, sqlParams) {
  return new Promise((resolve, reject) => {
    client.query(sqlQuery, sqlParams, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}

router.post("/user_exam", async (req, res) => {
  try {
    const { email, category_id } = req.body;

    if (!email || !category_id) {
      return res.status(400).json({
        message: "Invalid input",
      });
    }

    const categoryQuery = `SELECT * FROM users WHERE email = $1;`;
    const examIdQuery = `SELECT * FROM exam WHERE category_id = $1;`;

    Promise.all([
      executeQuery(categoryQuery, [email]),
      executeQuery(examIdQuery, [category_id]),
    ])
      .then(([categoryResult, examIdResult]) => {
        if (categoryResult.rowCount === 0) {
          return res.status(404).json({
            message: "Email not found",
          });
        }
        if (examIdResult.rowCount === 0) {
          return res.status(404).json({
            message: "Exam not found",
          });
        }

        const insertQuery = `INSERT INTO User_exam (email, category_id) VALUES ($1, $2)`;
        executeQuery(insertQuery, [email, category_id])
          .then(() => {
            res.json({
              message: "User submitted for exam",
            });
          })
          .catch((err) => {
            console.log(err);
            return res.status(500).json({
              message: "Internal server error",
            });
          });
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          message: "Internal server error",
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

module.exports = router;
